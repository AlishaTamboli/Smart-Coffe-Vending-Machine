package com.we6.vending_machine_monitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendingMachineMonitoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
