package com.we6.java.vending_machine_monitoring.Config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.context.annotation.Bean;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(requests -> requests
                        .requestMatchers(
                                "/api/users/register",
                                "/api/users/login",
                                "/api/users/reset/verify-user",
                                "/api/users/reset/verify-answer",
                                "/api/users/reset/password",
                                "/api/branches",
                                "/api/buildings",
                                "/api/floors",
                                "/api/machines",
                                "/api/locations",
                                "/api/machine-details",
                                "/api/machine/update",
                                "/", "/index.html", "/ResetPage.html","/technician.html", "/admin.html", "/admin_home.html",
                                "/admin_profile.html", "/admin_machines.html", "/admin_technicians.html",
                                "/admin_feedbacks.html", "/tech.css", "/tech.js", "/style.css", "/admin.css",
                                "/app.js", "/admin.js", "/api/admin/profile", "/HomePage.html",
                                "/api/admin/machine-details","/api/admin/machine-status",
                                "/feedback_form.html", "/coffee_review.html", "/coffee_vending_machine_review.html",
                                "/api/admin/sync",
                                "/api/machines/**", "/api/technicians/**", "/api/feedback/**", "/api/technician/**",
                                "/css/**", "/js/**", "/images/**","/sound/**"
                        ).permitAll()
                        .requestMatchers("/api/**").authenticated())
                .formLogin(login -> login.disable())
                .logout(logout -> logout.permitAll());

        return http.build();
    }

    
}

