package com.we6.java.vending_machine_monitoring.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.we6.java.vending_machine_monitoring.Model.Technician;
import com.we6.java.vending_machine_monitoring.service.TechnicianService;

import java.util.List;
 
@RestController
@RequestMapping("/api/technicians")
public class TechnicianController {
    
    @Autowired
    private TechnicianService technicianService;
    
    @GetMapping
    public ResponseEntity<List<Technician>> getAllTechnicians(
            @RequestParam(required = false) String search) {
        List<Technician> technicians;
        if (search != null && !search.isEmpty()) {
            technicians = technicianService.searchTechnicians(search);
        } else {
            technicians = technicianService.getAllTechnicians();
        }
        return ResponseEntity.ok(technicians);
    }
}
 