package com.we6.java.vending_machine_monitoring.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.we6.java.vending_machine_monitoring.Model.Technician;


public interface TechnicianRepository extends JpaRepository<Technician, Long> {
    boolean existsByEmpId(String empId);

    Technician findByEmail(String email); 

    @Query("SELECT t FROM Technician t WHERE " +
           "LOWER(t.firstName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(t.lastName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(t.location) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Technician> searchTechnicians(@Param("query") String query);
}

   
