package com.we6.java.vending_machine_monitoring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.we6.java.vending_machine_monitoring.Model.CoffeMachineFeedback;
import com.we6.java.vending_machine_monitoring.Model.CoffeReviewFeedback;
import com.we6.java.vending_machine_monitoring.Repository.CoffeeMachineFeedbackRepository;
import com.we6.java.vending_machine_monitoring.Repository.CoffeeReviewFeedbackRepository;

@Service
public class FeedbackService {

    @Autowired
    private CoffeeMachineFeedbackRepository machineRepo;

    @Autowired
    private CoffeeReviewFeedbackRepository reviewRepo;

    public CoffeMachineFeedback saveMachineFeedback(CoffeMachineFeedback feedback) {
        return machineRepo.save(feedback);
    }

    public List<CoffeMachineFeedback> getAllMachineFeedback() {
        return machineRepo.findAll();
    }

    public CoffeReviewFeedback saveReviewFeedback(CoffeReviewFeedback feedback) {
        return reviewRepo.save(feedback);
    }

    public List<CoffeReviewFeedback> getAllReviewFeedback() {
        return reviewRepo.findAll();
    }
}
