package com.we6.java.vending_machine_monitoring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.we6.java.vending_machine_monitoring.Model.Technician;
import com.we6.java.vending_machine_monitoring.Repository.TechnicianRepository;

@Service
public class TechnicianService {
    @Autowired
    private TechnicianRepository technicianRepository;
    
    public List<Technician> getAllTechnicians() {
        return technicianRepository.findAll();
    }
    
    public List<Technician> searchTechnicians(String query) {
        return technicianRepository.searchTechnicians(query);
    }
    
}
