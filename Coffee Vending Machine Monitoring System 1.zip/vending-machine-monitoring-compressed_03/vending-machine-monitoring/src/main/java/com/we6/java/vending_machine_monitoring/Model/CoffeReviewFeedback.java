package com.we6.java.vending_machine_monitoring.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class CoffeReviewFeedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String taste;
    private String aroma;
    private String temperature;
    private String drinkAgain;
    private String recommend;
    private String satisfaction;

    public CoffeReviewFeedback() {}

    public CoffeReviewFeedback(String taste, String aroma, String temperature, String drinkAgain, String recommend, String satisfaction) {
        this.taste = taste;
        this.aroma = aroma;
        this.temperature = temperature;
        this.drinkAgain = drinkAgain;
        this.recommend = recommend;
        this.satisfaction = satisfaction;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTaste() {
        return taste;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }

    public String getAroma() {
        return aroma;
    }

    public void setAroma(String aroma) {
        this.aroma = aroma;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getDrinkAgain() {
        return drinkAgain;
    }

    public void setDrinkAgain(String drinkAgain) {
        this.drinkAgain = drinkAgain;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public String getSatisfaction() {
        return satisfaction;
    }

    public void setSatisfaction(String satisfaction) {
        this.satisfaction = satisfaction;
    }
}
