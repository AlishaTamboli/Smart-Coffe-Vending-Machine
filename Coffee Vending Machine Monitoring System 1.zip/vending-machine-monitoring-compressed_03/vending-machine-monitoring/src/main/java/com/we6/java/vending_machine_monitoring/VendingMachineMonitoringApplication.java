package com.we6.java.vending_machine_monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendingMachineMonitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendingMachineMonitoringApplication.class, args);
		System.out.println("Hi this is Coffee Vending Machine Monitoring System");
	}

}
