package com.we6.java.vending_machine_monitoring.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;


@Data
@AllArgsConstructor
public class MachineStatusDTO {
    private String machineId;
    private double temperature;
    private double milkLevel;
    private double coffeeLevel;
    private double sugarLevel;
    @JsonFormat(pattern = "MMM dd, yyyy HH:mm:ss")
    private LocalDateTime updatedAt;
    private String updatedBy;
}
