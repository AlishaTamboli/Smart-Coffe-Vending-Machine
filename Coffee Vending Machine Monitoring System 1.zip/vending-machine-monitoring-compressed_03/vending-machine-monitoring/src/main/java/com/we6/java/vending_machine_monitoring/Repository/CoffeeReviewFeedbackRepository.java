package com.we6.java.vending_machine_monitoring.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.we6.java.vending_machine_monitoring.Model.CoffeReviewFeedback;

public interface CoffeeReviewFeedbackRepository extends JpaRepository<CoffeReviewFeedback, Long> {
}
