package com.we6.java.vending_machine_monitoring.DTO;

import com.we6.java.vending_machine_monitoring.Model.Machine;
import com.we6.java.vending_machine_monitoring.Model.MachineDetails;
public class MachineWithDetailsDTO {
    private Machine machine;
    private MachineDetails details;

    public MachineWithDetailsDTO(Machine machine, MachineDetails details) {
        this.machine = machine;
        this.details = details;
    }

    public Machine getMachine() {
        return machine;
    }

    public void setMachine(Machine machine) {
        this.machine = machine;
    }

    public MachineDetails getDetails() {
        return details;
    }

    public void setDetails(MachineDetails details) {
        this.details = details;
    }
}


// DTO = Data Transfer Object
// This class is used to transfer data between the controller and the service layer.

// Model = full table with all fields
// DTO = only the safe, needed fields (no sensitive info)