package com.we6.java.vending_machine_monitoring.service;

import com.we6.java.vending_machine_monitoring.Model.Admin;
import com.we6.java.vending_machine_monitoring.Model.User;
import com.we6.java.vending_machine_monitoring.Repository.AdminRepository;
import com.we6.java.vending_machine_monitoring.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    public Admin loginAsAdmin(String email, String password) {
        Optional<User> userOpt = userRepository.findByEmailAndPassword(email, password);
        if (userOpt.isPresent() && "admin".equalsIgnoreCase(userOpt.get().getRole())) {
            return adminRepository.findByEmail(email).orElse(null);
        }
        return null;
    }
}
