package com.we6.java.vending_machine_monitoring.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.we6.java.vending_machine_monitoring.Model.Admin;

import java.util.Optional;

public interface AdminRepository extends JpaRepository<Admin, Long> {
    Optional<Admin> findByEmail(String email);
}
