package com.we6.java.vending_machine_monitoring.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.we6.java.vending_machine_monitoring.Model.Admin;
import com.we6.java.vending_machine_monitoring.Model.Technician;
import com.we6.java.vending_machine_monitoring.Model.User;
import com.we6.java.vending_machine_monitoring.Repository.AdminRepository;
import com.we6.java.vending_machine_monitoring.Repository.UserRepository;
import com.we6.java.vending_machine_monitoring.Repository.TechnicianRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private TechnicianRepository technicianRepository;


    @SuppressWarnings({"unused", "CallToPrintStackTrace"})
    @Transactional
    public void registerUser(User user) {
        User savedUser = userRepository.save(user);
        // System.out.println("Saved user ID: " + savedUser.getId());

        // Check if role is admin
        if ("admin".equalsIgnoreCase(user.getRole().trim())) {
            Admin admin = new Admin();
            admin.setFirstName(user.getFirstName());
            admin.setLastName(user.getLastName());
            admin.setEmployeeId(user.getEmployeeId());
            admin.setRole(user.getRole());
            admin.setEmail(user.getEmail());
            admin.setPhone(user.getPhone());
            admin.setLocation(user.getLocation());

            try {
                adminRepository.saveAndFlush(admin);
                System.out.println("Admin saved to admin table.");
            } catch (Exception e) {
                System.err.println("Error saving admin: " + e.getMessage());
                e.printStackTrace();
            }
        }

        // Technician logic 
        if ("technician".equalsIgnoreCase(user.getRole().trim())) {
            if (technicianRepository.findByEmail(user.getEmail()) == null) {
                Technician technician = new Technician();
                technician.setFirstName(user.getFirstName());
                technician.setLastName(user.getLastName());
                technician.setEmpId(user.getEmployeeId());
                technician.setRole(user.getRole());
                technician.setEmail(user.getEmail());
                technician.setPhone(user.getPhone());
                technician.setLocation(user.getLocation());

                technicianRepository.save(technician);
            }
        }
    }


     public Optional<User> login(String email, String password) {
        return userRepository.findByEmailAndPassword(email, password);
     }
    
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public boolean adminEmailExistsIgnoreCase(String email) {
        return adminRepository.findAll().stream()
            .anyMatch(admin -> admin.getEmail().trim().equalsIgnoreCase(email.trim()));
    }    
    
    public Optional<User> findByEmployeeId(String empId) {
        return userRepository.findByEmployeeId(empId);
    }
    
    public void save(User user) {
        userRepository.save(user);
    }
        
}
