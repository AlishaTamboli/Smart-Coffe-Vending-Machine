package com.we6.java.vending_machine_monitoring.Controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.we6.java.vending_machine_monitoring.Model.User;
import com.we6.java.vending_machine_monitoring.service.UserService;

import jakarta.servlet.http.HttpServletRequest;



@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/users")

public class UserController {
 
    @Autowired
    private UserService userService;
 
    
    @PostMapping("/register")
    @SuppressWarnings("CallToPrintStackTrace")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        // System.out.println("Received user: " + user);
        try {
            userService.registerUser(user);
            return ResponseEntity.ok("User registered successfully");
        } catch (Exception e) {
            e.printStackTrace(); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed: " + e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user, HttpServletRequest request) {
        Optional<User> userOpt = userService.login(user.getEmail(), user.getPassword());

        if (userOpt.isPresent()) {
            User loggedInUser = userOpt.get();
            //  Store user in session
            request.getSession().setAttribute("user", loggedInUser);
            // System.out.println("Session set for user: " + loggedInUser.getEmail());
            // Return user info 
            return ResponseEntity.ok(loggedInUser);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    @PostMapping("/reset/verify-user")
    public ResponseEntity<?> verifyUser(@RequestBody Map<String, String> payload) {
        String identifier = payload.get("identifier");

        Optional<User> userOpt = identifier.contains("@")
            ? userService.findByEmail(identifier)
            : userService.findByEmployeeId(identifier);

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            Map<String, String> response = new HashMap<>();
            response.put("success", "true");
            response.put("securityQuestion", user.getSecurityQuestion());
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.ok(Map.of("success", "false"));
        }
    }

    @PostMapping("/reset/verify-answer")
    public ResponseEntity<?> verifyAnswer(@RequestBody Map<String, String> payload) {
        String identifier = payload.get("identifier");
        String answer = payload.get("answer");

        Optional<User> userOpt = identifier.contains("@")
            ? userService.findByEmail(identifier)
            : userService.findByEmployeeId(identifier);

        if (userOpt.isPresent() && userOpt.get().getSecurityAnswer().equalsIgnoreCase(answer.trim())) {
            return ResponseEntity.ok(Map.of("success", "true"));
        } else {
            return ResponseEntity.ok(Map.of("success", "false"));
        }
    }

    @PostMapping("/reset/password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> payload) {
        String identifier = payload.get("identifier");
        String newPassword = payload.get("newPassword");

        Optional<User> userOpt = identifier.contains("@")
            ? userService.findByEmail(identifier)
            : userService.findByEmployeeId(identifier);

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setPassword(newPassword);
            userService.save(user);
            return ResponseEntity.ok(Map.of("success", "true"));
        } else {
            return ResponseEntity.ok(Map.of("success", "false"));
        }
    }

}