package com.we6.java.vending_machine_monitoring.Controller;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.we6.java.vending_machine_monitoring.Model.MachineDetails;
import com.we6.java.vending_machine_monitoring.Model.User;
import com.we6.java.vending_machine_monitoring.Repository.MachineDetailsRepository;
import com.we6.java.vending_machine_monitoring.Repository.UserRepository;
import com.we6.java.vending_machine_monitoring.service.MachineService;
 
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class MachineController {
 
    @Autowired private MachineService machineService;
    @Autowired private MachineDetailsRepository detailsRepo;
    @Autowired private UserRepository userRepo;
 
    @GetMapping("/technician/email/{email}")
public ResponseEntity<User> getTechnicianByEmail(@PathVariable String email) {
    return userRepo.findByEmail(email)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
}
 
 
    @GetMapping("/locations")
    public List<String> getAllLocations() {
        return machineService.getAllLocations();
    }
 
    @GetMapping("/branches")
    public List<String> getBranches(@RequestParam String location) {
        return machineService.getBranches(location);
    }
 
    @GetMapping("/buildings")
    public List<String> getBuildings(@RequestParam String location, @RequestParam String branch) {
        return machineService.getBuildings(location, branch);
    }
 
    @GetMapping("/floors")
    public List<String> getFloors(@RequestParam String location, @RequestParam String branch, @RequestParam String building) {
        return machineService.getFloors(location, branch, building);
    }
 
    @GetMapping("/machines")
    public List<String> getMachines(@RequestParam String location, @RequestParam String branch, @RequestParam String building, @RequestParam String floor) {
        return machineService.getMachines(location, branch, building, floor);
    }
 
    @PostMapping("/machine-details")
    public ResponseEntity<String> saveOrUpdateMachineDetails(@RequestBody MachineDetails details) {
        details.setUpdatedAt(LocalDateTime.now());
    
        // technician machineController
        Optional<MachineDetails> existing = detailsRepo.findByMachine_MachineId(details.getMachine().getMachineId());
        if (existing.isPresent()) {
            MachineDetails existingDetails = existing.get();
            existingDetails.setTemperature(details.getTemperature());
            existingDetails.setMilkLevel(details.getMilkLevel());
            existingDetails.setCoffeeLevel(details.getCoffeeLevel());
            existingDetails.setSugarLevel(details.getSugarLevel());
            existingDetails.setUpdatedAt(details.getUpdatedAt());
            detailsRepo.save(existingDetails);
        } else {
            detailsRepo.save(details);
        }
    
        return ResponseEntity.ok("Machine details saved successfully");
    }
    
    @GetMapping("/machine-details")
        public List<MachineDetails> getAllMachineDetails() {
        return detailsRepo.findAll();
    }

}
 