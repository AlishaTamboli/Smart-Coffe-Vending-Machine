package com.we6.java.vending_machine_monitoring.Model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class MachineDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @SuppressWarnings("unused")
    private Long id;

    private Double temperature;
    private Double milkLevel;
    private Double coffeeLevel;
    private Double sugarLevel;
    @JsonFormat(pattern = "MMM dd, yyyy HH:mm:ss")
    private LocalDateTime updatedAt;


    @Column(name = "updated_by")
    private String updatedBy;

    @ManyToOne
    @JoinColumn(name = "machine_id", referencedColumnName = "machineId")
    @SuppressWarnings("unused")
    private Machine machine;

    
    // Getters and setters...
    public double getCoffeeLevel() {
        return coffeeLevel;
    }

    public void setCoffeeLevel(double coffeeLevel) {
        this.coffeeLevel = coffeeLevel;
    }

    public double getSugarLevel() {
        return sugarLevel;
    }

    public void setSugarLevel(double sugarLevel) {
        this.sugarLevel = sugarLevel;
    }

    public double getMilkLevel() {
        return milkLevel;
    }

    public void setMilkLevel(double milkLevel) {
        this.milkLevel = milkLevel;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    public String getUpdatedBy() {
        return updatedBy;
    }
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}
