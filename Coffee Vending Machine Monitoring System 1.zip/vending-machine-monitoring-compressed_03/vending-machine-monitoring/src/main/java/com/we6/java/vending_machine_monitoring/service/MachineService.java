package com.we6.java.vending_machine_monitoring.service;
 
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.we6.java.vending_machine_monitoring.DTO.MachineWithDetailsDTO;
import com.we6.java.vending_machine_monitoring.Model.Machine;
import com.we6.java.vending_machine_monitoring.Model.MachineDetails;
import com.we6.java.vending_machine_monitoring.Repository.MachineDetailsRepository;
import com.we6.java.vending_machine_monitoring.Repository.MachineRepository;
 
@Service
public class MachineService {
 
    @Autowired private MachineRepository machineRepo;
    @Autowired private MachineDetailsRepository detailsRepo;


    public List<String> getAllLocations() {
        List<String> locations = machineRepo.findAll().stream()
            .map(Machine::getLocation)
            .filter(loc -> loc != null && !loc.trim().isEmpty())
            .map(String::trim)
            .distinct()
            .collect(Collectors.toList());
        // System.out.println("DEBUG: Locations fetched from DB: " + locations);
        return locations;
    }
   
   
 
    public List<String> getBranches(String location) {
        return machineRepo.findByLocation(location).stream()
                .map(Machine::getBranch)
                .distinct()
                .collect(Collectors.toList());
    }
 
    public List<String> getBuildings(String location, String branch) {
        return machineRepo.findByLocationAndBranch(location, branch).stream()
                .map(Machine::getBuilding)
                .distinct()
                .collect(Collectors.toList());
    }
 
    public List<String> getFloors(String location, String branch, String building) {
        return machineRepo.findByLocationAndBranchAndBuilding(location, branch, building).stream()
                .map(Machine::getFloor)
                .distinct()
                .collect(Collectors.toList());
    }
 
    public List<String> getMachines(String location, String branch, String building, String floor) {
        return machineRepo.findByLocationAndBranchAndBuildingAndFloor(location, branch, building, floor).stream()
                .map(Machine::getMachineId)
                .collect(Collectors.toList());
    }
    
    public List<Machine> getAllMachines() {
        return machineRepo.findAll();
    }
    public List<Machine> getMachinesByLocation(String location) {
        return machineRepo.findByLocation(location);
    }
    public List<Machine> getMachinesByLocationAndBranch(String location, String branch) {
        return machineRepo.findByLocationAndBranch(location, branch);
    }
    
    public List<MachineWithDetailsDTO> getAllMachinesWithDetails() {
        List<MachineDetails> detailsList = detailsRepo.findAll();
        List<MachineWithDetailsDTO> result = new ArrayList<>();
        for (MachineDetails details : detailsList) {
            Machine machine = details.getMachine(); 
            result.add(new MachineWithDetailsDTO(machine, details));
        }
        
        return result;
    }
         
}
 