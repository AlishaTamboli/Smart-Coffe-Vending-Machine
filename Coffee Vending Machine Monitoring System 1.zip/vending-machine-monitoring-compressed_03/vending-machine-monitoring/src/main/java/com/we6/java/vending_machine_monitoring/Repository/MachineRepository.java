package com.we6.java.vending_machine_monitoring.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.we6.java.vending_machine_monitoring.Model.Machine;


public interface MachineRepository extends JpaRepository<Machine, String> {
    List<Machine> findByLocation(String location);
    List<Machine> findByLocationAndBranch(String location, String branch);
    List<Machine> findByLocationAndBranchAndBuilding(String location, String branch, String building);
    List<Machine> findByLocationAndBranchAndBuildingAndFloor(String location, String branch, String building, String floor);
}
