package com.we6.java.vending_machine_monitoring.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.we6.java.vending_machine_monitoring.Model.CoffeMachineFeedback;
import com.we6.java.vending_machine_monitoring.Model.CoffeReviewFeedback;
import com.we6.java.vending_machine_monitoring.service.FeedbackService;

@RestController
@RequestMapping("/api/feedback")
@CrossOrigin(origins = "*")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    @PostMapping("/machineFeedback")
    public ResponseEntity<CoffeMachineFeedback> submitMachineFeedback(@RequestBody CoffeMachineFeedback feedback) {
        return ResponseEntity.ok(feedbackService.saveMachineFeedback(feedback));
    }

    @GetMapping("/machineFeedback")
    public ResponseEntity<List<CoffeMachineFeedback>> getMachineFeedback() {
        return ResponseEntity.ok(feedbackService.getAllMachineFeedback());
    }

    @PostMapping("/reviewFeedback")
    public ResponseEntity<CoffeReviewFeedback> submitReviewFeedback(@RequestBody CoffeReviewFeedback feedback) {
        return ResponseEntity.ok(feedbackService.saveReviewFeedback(feedback));
    }

    @GetMapping("/reviewFeedback")
    public ResponseEntity<List<CoffeReviewFeedback>> getReviewFeedback() {
        return ResponseEntity.ok(feedbackService.getAllReviewFeedback());
    }
}
