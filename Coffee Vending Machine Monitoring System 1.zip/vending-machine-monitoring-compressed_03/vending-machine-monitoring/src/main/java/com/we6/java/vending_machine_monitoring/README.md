1. You need Java SE 8 or later on your development machine.
2. Run `mvn clean package` to install the required libraries and build the simulated device application.
3. Run `java -jar target/simulated-device-1.0.0-with-deps.jar` to run the simulated device application.