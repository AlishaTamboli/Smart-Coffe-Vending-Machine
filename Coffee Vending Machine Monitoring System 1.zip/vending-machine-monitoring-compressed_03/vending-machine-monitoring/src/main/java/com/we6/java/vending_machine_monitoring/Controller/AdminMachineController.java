package com.we6.java.vending_machine_monitoring.Controller;
import java.util.Optional;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.we6.java.vending_machine_monitoring.DTO.MachineStatusDTO;
import com.we6.java.vending_machine_monitoring.DTO.MachineWithDetailsDTO;
import com.we6.java.vending_machine_monitoring.Repository.MachineDetailsRepository;
import com.we6.java.vending_machine_monitoring.service.MachineService;

import com.we6.java.vending_machine_monitoring.Model.MachineDetails;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminMachineController {
    @Autowired private MachineService machineService;
    @Autowired private MachineDetailsRepository detailsRepo;

    @GetMapping("/machines")
    public List<MachineWithDetailsDTO> getAllMachinesWithDetails() {
        return machineService.getAllMachines().stream()
            .map(machine -> {
                Optional<MachineDetails> detailsOpt = detailsRepo.findByMachine_MachineId(machine.getMachineId());
                return new MachineWithDetailsDTO(machine, detailsOpt.orElse(null));
            })
            .collect(Collectors.toList());
    }

    
    @GetMapping("/machine-details")
    public List<MachineWithDetailsDTO> getAllMachinesWithDetailsFromService() {
        return machineService.getAllMachinesWithDetails();
    }

    @GetMapping("/machine-status")
    public List<MachineStatusDTO> getMachineStatusForAlerts() {
        return machineService.getAllMachinesWithDetails().stream()
            .map(dto -> new MachineStatusDTO(
                dto.getMachine().getMachineId(),
                dto.getDetails().getTemperature(),
                dto.getDetails().getMilkLevel(),
                dto.getDetails().getCoffeeLevel(),
                dto.getDetails().getSugarLevel(),
                dto.getDetails().getUpdatedAt(),
                dto.getDetails().getUpdatedBy()
            ))
            .collect(Collectors.toList());
    }


}
