package com.we6.java.vending_machine_monitoring.Repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.we6.java.vending_machine_monitoring.Model.MachineDetails;


@Repository
public interface MachineDetailsRepository extends JpaRepository<MachineDetails, Long> {
    Optional<MachineDetails> findByMachine_MachineId(String machineId);
}

