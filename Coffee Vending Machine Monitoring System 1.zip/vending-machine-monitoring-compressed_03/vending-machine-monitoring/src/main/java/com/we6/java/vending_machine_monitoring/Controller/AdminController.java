package com.we6.java.vending_machine_monitoring.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.servlet.http.HttpServletRequest;


import com.we6.java.vending_machine_monitoring.Model.Admin;
import com.we6.java.vending_machine_monitoring.Model.User;
import com.we6.java.vending_machine_monitoring.Repository.AdminRepository;


@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminRepository adminRepository;



    @GetMapping("/profile")
    public ResponseEntity<Admin> getAdminProfile(HttpServletRequest request) {
    User user = (User) request.getSession().getAttribute("user");
        if (user != null && "admin".equalsIgnoreCase(user.getRole())) {
            return adminRepository.findByEmail(user.getEmail())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

        
}



