function loadPage(page) {
  const contentArea = document.getElementById('content-area');
  // Save the selected page to localStorage
  localStorage.setItem('currentPage', page);
  // Highlight the active sidebar item
  document.querySelectorAll('.sidebar-nav li').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('onclick')?.includes(page)) {
      item.classList.add('active');
    }
  });

  // Load the page content
  fetch(`${page}.html`)
    .then(response => {
      if (!response.ok) {
        throw new Error("Page not found");
      }
      return response.text();
    })
    .then(data => {
      contentArea.innerHTML = data;
    
      if (page === "admin_profile" && typeof loadAdminProfile === "function") {
        loadAdminProfile();
      } else if (page === "admin_technicians" && typeof fetchTechnicians === "function") {
        fetchTechnicians();
      } else if (page === "admin_machines" && typeof fetchMachineData === "function") {
        fetchMachineData();
      } else if (page === "admin_feedbacks" && typeof loadFeedback === "function") {
        loadFeedback();
      } else if (page === "admin_home" && typeof loadAdminHome === "function") {
        loadAdminHome();
      }
    })
    
    
    .catch(error => {
      contentArea.innerHTML = `<p>Error loading page: ${error.message}</p>`;
    });
}

function logoutAdmin() {
  localStorage.clear();
  sessionStorage.clear();

  Swal.fire({
    icon: 'success',
    title: 'Logged out',
    text: 'You have been successfully logged out!',
    confirmButtonText: 'OK'
  }).then(() => {
    window.location.href = 'HomePage.html';
  });
}


// Load the saved page or default to 'home' on initial load
document.addEventListener("DOMContentLoaded", () => {
  const savedPage = localStorage.getItem('currentPage') || 'home';
  // Highlight the correct sidebar item on page load
  document.querySelectorAll('.sidebar-nav li').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('onclick')?.includes(savedPage)) {
      item.classList.add('active');
    }
  });
  loadPage(savedPage);
});


//alerts.js
// Thresholds for alerts
const thresholds = {
  temperature: { min: 60, max: 90 },
  milkLevel: 3,
  coffeeBeans: 1000,
  sugarLevel: 80
};

const alerts = [];
// Get current timestamp in readable format
function getCurrentTimestamp() {
  const now = new Date();
  return now.toLocaleString(); // e.g., "17/5/2025, 2:30:00 PM"
}

// Fetch machine data and generate alerts
function fetchMachineDataAndCheckAlerts() {
  fetch("/api/admin/machine-status") // Adjust this endpoint if needed
    .then(response => response.json())
    .then(data => {
      alerts.length = 0;

      data.forEach(machine => {
        const id = machine.machineId;
        const time = getCurrentTimestamp();

        if (machine.temperature < thresholds.temperature.min) {
          alerts.push({
            title: `⚠️ ${id}: Low Temperature`,
            details: `Current Temperature: ${machine.temperature}°C
            Min Temperature: ${thresholds.temperature.min}°C
            Timestamp: ${machine.updatedAt}
            updatedBy: ${machine.updatedBy}`
          });
        } else if (machine.temperature > thresholds.temperature.max) {
          alerts.push({
            title: `🔥 ${id}: High Temperature`,
            details: `Current Temperature: ${machine.temperature}°C 
            Max Temperature: ${thresholds.temperature.max}°C
            Timestamp: ${machine.updatedAt}
            updatedBy: ${machine.updatedBy}`
          });
        }

        if (machine.milkLevel < thresholds.milkLevel) {
          alerts.push({
            title: `🥛 ${id}: Milk level low`,
            details: `Current Level: ${machine.milkLevel} L
            Min Level: ${thresholds.milkLevel} L
            Timestamp: ${machine.updatedAt}
            updatedBy: ${machine.updatedBy}`
          });
        }

        if (machine.coffeeBeans < thresholds.coffeeBeans) {
          alerts.push({
            title: `☕ ${id}: Low Coffee Beans Quantity`,
            details: `Current Quantity: ${machine.coffeeBeans} g 
            Min Quantity: ${thresholds.coffeeBeans} g 
            Timestamp: ${machine.updatedAt}
            updatedBy: ${machine.updatedBy}`
          });
        }

        if (machine.sugarLevel < thresholds.sugarLevel) {
          alerts.push({
            title: `🍬 ${id}: Less Number of Sugar Sachets`,
            details: `Current Quantity: ${machine.sugarLevel}
            Min Quantity: ${thresholds.sugarLevel}
            Timestamp: ${machine.updatedAt}
            updatedBy: ${machine.updatedBy}`
          });
        }
        
      });

      updateNotificationUI();
    })
    .catch(error => console.error("Error fetching machine data:", error));
}

// Update the notification dropdown UI
function updateNotificationUI() {
  const count = alerts.length;
  document.getElementById("notification-count").textContent = count;
  const list = document.getElementById("notification-list");
  list.innerHTML = "";

  alerts.forEach(alert => {
    const li = document.createElement("li");
    li.innerHTML = `
      <strong>${alert.title}</strong><br/>
      ${alert.details}<br/>
    `;
    list.appendChild(li);
  });
}

// Toggle dropdown visibility
document.getElementById("notification-bell").addEventListener("click", () => {
  const dropdown = document.getElementById("notification-dropdown");
  dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
});

// Update timestamp every second
function updateTimestamp() {
  const timestampElement = document.getElementById('timestamp');
  const now = new Date();
  const formattedDate = now.toLocaleDateString('en-US', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });
  const formattedTime = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  timestampElement.innerHTML = `${formattedDate}<br>${formattedTime}`;
}
setInterval(updateTimestamp, 1000);
updateTimestamp();

// Start polling machine data every 10 seconds
setInterval(fetchMachineDataAndCheckAlerts, 10000);
fetchMachineDataAndCheckAlerts();


 
// profile.js
function loadAdminProfile() {
  fetch("/api/admin/profile", {
    method: "GET",
    credentials: "include"
  })
    .then(response => {
      if (!response.ok) throw new Error("Unauthorized or not found");
      return response.json();
    })
    .then(data => {
      document.getElementById("firstName").textContent = data.firstName;
      document.getElementById("lastName").textContent = data.lastName;
      document.getElementById("employeeId").textContent = data.employeeId;
      document.getElementById("role").textContent = data.role;
      document.getElementById("registeredEmail").textContent = data.email;
      document.getElementById("phone").textContent = data.phone;
      document.getElementById("location").textContent = data.location;
    })
    .catch(error => {
      console.error("Error loading profile:", error);
      alert("Failed to load profile. Please log in again.");
      window.location.href = "index.html";
    });
}





// technicians.js
  
let technicians = [];
// Fetch all technicians from backend
async function fetchTechnicians() {
  try {
    const response = await fetch('/api/technicians');
    technicians = await response.json();
    renderTechnicians(technicians);
  } catch (error) {
    console.error('Error fetching technician data:', error);
  }
}

// Render technician rows in the table
function renderTechnicians(data) {
  const tbody = document.getElementById('technician-body');
  tbody.innerHTML = '';

  data.forEach(tech => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${tech.empId || 'N/A'}</td>
      <td>${tech.firstName || 'N/A'}</td>
      <td>${tech.lastName || 'N/A'}</td>
      <td>${tech.email || 'N/A'}</td>
      <td>${tech.phone || 'N/A'}</td>
      <td>${tech.location || 'N/A'}</td>
    `;
    tbody.appendChild(row);
  });
}

// Filter technicians based on search input
function filterTechnicians() {
  const input = document.getElementById('searchInput').value.toLowerCase();
  const filtered = technicians.filter(tech => {
    const values = [
      tech.firstName,
      tech.lastName,
      tech.location,
      tech.building
    ].join(' ').toLowerCase();
    return values.includes(input);
  });
  renderTechnicians(filtered);
}
// Load technicians on page load
document.addEventListener('DOMContentLoaded', fetchTechnicians);

 
// machines.js

let machines = [];
// Fetch machine data from backend
async function fetchMachineData() {
  try {
    const response = await fetch('/api/admin/machine-details'); 
    machines = await response.json();
    renderMachineCards(machines);
  } catch (error) {
    console.error('Error fetching machine data:', error);
  }
}

function renderMachineCards(data) {
  const container = document.getElementById('machineCards');
  container.innerHTML = '';

  data.forEach(item => {
    const machine = item.machine || {};
    const details = item.details || {};

    const card = document.createElement('div');
    card.className = 'machine-card';
    card.innerHTML = `
      <h3>Machine ID: ${machine.machineId || 'N/A'}</h3>
      <p><strong>Location:</strong> ${machine.location || 'N/A'}</p>
      <p><strong>Branch:</strong> ${machine.branch ?? 'N/A'}</p>
      <p><strong>Building:</strong> ${machine.building || 'N/A'}</p>
      <p><strong>Floor:</strong> ${machine.floor || 'N/A'}</p>
      <p><strong>Temperature(in K):</strong> ${details.temperature ? (details.temperature + 273.15).toFixed(2) + ' K' : 'N/A'}</p>
      <p><strong>Milk Level:</strong> ${details.milkLevel + ' L' ?? 'N/A'}</p>
      <p><strong>Coffee Beans Quantity:</strong> ${details.coffeeLevel + ' g' ?? 'N/A'}</p>
      <p><strong>Sugar Sachets:</strong> ${details.sugarLevel ?? 'N/A'}</p>
      <p><strong>Updated At:</strong> ${details.updatedAt ?? 'N/A'}</p>
      <p><strong>Updated By:</strong> ${details.updatedBy ?? 'N/A'}</p>

    `;
    container.appendChild(card);
  });
}

// Filter machine cards based on search input
function filterMachineCards() {
  const input = document.getElementById('machineSearchInput').value.toLowerCase();

  const filtered = machines.filter(item => {
    const machine = item.machine || {};
    const details = item.details || {};
    // Combine keys and values from machine and details
    const machineEntries = Object.entries(machine).map(([key, val]) => `${key} ${val}`);
    const detailEntries = Object.entries(details).map(([key, val]) => {
      if (key === 'temperature' && typeof val === 'number') {
        const kelvin = (val + 273.15).toFixed(2);
        return `${key} ${val} ${kelvin} k`;
      }
      return `${key} ${val}`;
    });

    const searchableText = [...machineEntries, ...detailEntries]
      .map(entry => entry.toLowerCase())
      .join(' ');

    return searchableText.includes(input);
  });

  renderMachineCards(filtered);
}
// Load machine data on page load
document.addEventListener('DOMContentLoaded', fetchMachineData);

 
 
// feedbacks.js
function showTab(tabId) {
  // Hide all tab contents
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });

  // Show selected tab
  const selectedTab = document.getElementById(tabId);
  if (selectedTab) {
    selectedTab.classList.add('active');
  }

  // Toggle tab buttons and back button
  document.getElementById('tab-buttons').style.display = 'none';
  document.getElementById('back-button').style.display = 'block';
}

function goBack() {
  // Hide all tab contents
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });

  // Show tab buttons again
  document.getElementById('tab-buttons').style.display = 'block';
  document.getElementById('back-button').style.display = 'none';
}

function renderStars(rating) {
  return '★'.repeat(rating) + '☆'.repeat(5 - rating);
}

async function loadFeedback() {
  try {
    const [machineRes, coffeeRes] = await Promise.all([
      fetch('/api/feedback/machineFeedback'),
      fetch('/api/feedback/reviewFeedback')
    ]);

    const machineData = await machineRes.json();
    const coffeeData = await coffeeRes.json();

    const machineTable = document.getElementById('overall-feedback');
    machineTable.innerHTML = '';
    machineData.forEach((item, index) => {
      machineTable.innerHTML += `
        <tr>
          <td>${index + 1}</td>
          <td>${renderStars(item.starRating)}</td>
          <td>${item.comment}</td>
        </tr>`;
    });

    const coffeeTable = document.getElementById('item-feedback');
    coffeeTable.innerHTML = '';
    coffeeData.forEach((item, index) => {
      coffeeTable.innerHTML += `
        <tr>
          <td>${index + 1}</td>
          <td>${item.taste}</td>
          <td>${item.aroma}</td>
          <td>${item.temperature}</td>
          <td>${item.drinkAgain}</td>
          <td>${item.recommend}</td>
          <td>${item.satisfaction}</td>
        </tr>`;
    });
  } catch (error) {
    console.error('Error loading feedback:', error);
  }
}

document.addEventListener('DOMContentLoaded', loadFeedback);
