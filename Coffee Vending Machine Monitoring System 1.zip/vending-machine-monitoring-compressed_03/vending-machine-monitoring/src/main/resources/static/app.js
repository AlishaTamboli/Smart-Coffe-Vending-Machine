document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  try {
    const response = await fetch('http://localhost:8080/api/users/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });

    if (response.ok) {
      const data = await response.json();
      localStorage.setItem("technicianEmail", email);

      // Play sound
      const sound = document.getElementById("coffeeSound");
      if (sound) {
        sound.currentTime = 0;
        sound.volume = 1.0;
        sound.play().catch(err => console.log("Audio play blocked:", err));
      }

      // Show success toast
      Toastify({
        text: "☕ Login Successful!",
        duration: 3000,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
        style: {
          background: "linear-gradient(to right, #4b2e2e, #a47148)",
          color: "#fff8f0",
          fontWeight: "bold",
          fontFamily: "'Segoe UI', sans-serif",
          borderRadius: "8px",
          boxShadow: "0 4px 8px rgba(0,0,0,0.3)",
          padding: "12px 20px"
        }
      }).showToast();

      // Redirect based on role after short delay
      setTimeout(() => {
        if (data.role === 'Technician') {
          window.location.href = 'technician.html';
        } else if (data.role === 'Admin') {
          localStorage.setItem('currentPage', 'admin_home');
          window.location.href = 'admin.html';
        } else {
          Toastify({
            text: "⚠️ Unknown role: " + data.role,
            duration: 3000,
            gravity: "top",
            position: "right",
            backgroundColor: "#ff9800",
            stopOnFocus: true
          }).showToast();
        }
      }, 1150);

    } else {
      const errorText = await response.text();
      Toastify({
        text: "❌ Login failed: " + errorText,
        duration: 3000,
        gravity: "top",
        position: "right",
        backgroundColor: "#e53935",
        stopOnFocus: true
      }).showToast();
    }
  } catch (error) {
    console.error('Error logging in:', error);
    Toastify({
      text: "❌ An error occurred during login.",
      duration: 3000,
      gravity: "top",
      position: "right",
      backgroundColor: "#e53935",
      stopOnFocus: true
    }).showToast();
  }
});
 
console.log("Loaded user from localStorage:", localStorage.getItem("userEmail"));
 

// VALIDATION HELPERS
function isAlphabetic(str) {
  return /^[A-Za-z]+$/.test(str);
}
 
function isValidPhone(phone) {
  return /^[6-9]\d{9}$/.test(phone); // Starts with 6-9 and has 10 digits
}
 
function isValidEmail(email) {
  const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.com$/;
  return regex.test(email);
}
 
 
function isStrongPassword(password) {
  return /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,20}$/.test(password);
}
 

// Register form submission
document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
 
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const employeeId = document.getElementById('employeeId').value;
  const role = document.getElementById('role').value;
  const email = document.getElementById('registerEmail').value;
  const phone = document.getElementById('phone').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  const location = document.getElementById('location').value;
 
  if (!role || role === "Select your Role") {
    alert('Please select a role.');
    return;
  }
 
  if (!location || location === "Select your location") {
    alert('Please select a location.');
    return;
  }
 
  if (!isAlphabetic(firstName) || !isAlphabetic(lastName)) {
    alert('First and Last names should contain only letters.');
    return;
  }
 
  if (firstName.toLowerCase() === lastName.toLowerCase()) {
    alert('First and Last names can not be same');
    return;
  }
 
 
  if (!isValidPhone(phone)) {
    alert('Phone number must start with 6, 7, 8, or 9 and be exactly 10 digits.');
    return;
  }
 
  if (!isValidEmail(email)) {
    alert('Please enter a valid email ending in .com (e.g., user@example.com).');
    return;
  }

  const securityQuestion = document.getElementById('securityQuestion').value;
  const securityAnswer = document.getElementById('securityAnswer').value;

 
  if (!isStrongPassword(password)) {
    alert('Password must be 8-20 characters long and include at least one uppercase letter, one number, and one special character.');
    return;
  }
 
  if (password !== confirmPassword) {
    alert('Passwords do not match!');
    return;
  }
 

  const user = {
    firstName,
    lastName,
    employeeId,
    role,
    email,
    phone,
    location,
    password,
    securityQuestion,
    securityAnswer
  };
 
  try {
    const response = await fetch('http://localhost:8080/api/users/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user),
    });
  
    if (response.ok) {
      const sound = document.getElementById("coffeeSound");
  
      Toastify({
        text: "✅ Registration successful!",
        duration: 1500,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
        className: "custom-toast"
      }).showToast();
  
      if (sound) {
        sound.currentTime = 0;
        sound.volume = 1.0;
  
        sound.play().then(() => {
          sound.onended = () => {
            window.location.href = 'index.html';
          };
        }).catch(err => {
          console.log("Audio play blocked:", err);
          // Fallback redirect if audio fails
          setTimeout(() => {
            window.location.href = 'index.html';
          }, 1500);
        });
      } else {
        // If sound element not found, fallback to timed redirect
        setTimeout(() => {
          window.location.href = 'index.html';
        }, 1100);
      }
  
    } else {
      const errorText = await response.text();
      Toastify({
        text: "❌ Registration failed: " + errorText,
        duration: 4000,
        gravity: "top",
        position: "right",
        backgroundColor: "#e53935",
        stopOnFocus: true
      }).showToast();
    }
  } catch (error) {
    console.error('Error registering:', error);
    Toastify({
      text: "❌ An error occurred during registration.",
      duration: 4000,
      gravity: "top",
      position: "right",
      backgroundColor: "#e53935",
      stopOnFocus: true
    }).showToast();
  }
  
  
});


document.addEventListener("DOMContentLoaded", function () {
  const selects = document.querySelectorAll("select");

  selects.forEach(select => {
    select.addEventListener("change", function () {
      if (this.value !== "") {
        this.classList.add("valid-selection");
      } else {
        this.classList.remove("valid-selection");
      }
    });
  });
});
