let technicianLocation = "";
let technicianName = ""; //  Added to store technician's full name
 
function showSection(sectionId, buttonId) {
  const sections = ['backgroundImage', 'profileSection', 'updateSection'];
  sections.forEach(id => document.getElementById(id).classList.add('hidden'));
  document.getElementById(sectionId).classList.remove('hidden');
 
  const buttons = ['homeButton', 'profileButton', 'updateButton'];
  buttons.forEach(id => document.getElementById(id).classList.remove('active'));
  document.getElementById(buttonId).classList.add('active');
}
 
function updateTimestamp() {
  const now = new Date();
  const date = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
  const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  document.getElementById('timestamp').innerHTML = `${date} ${time}`;
}
setInterval(updateTimestamp, 1000);
updateTimestamp();
 
function fetchTechnicianProfile() {
  const email = localStorage.getItem("technicianEmail");
  if (!email) {
    alert("Technician email not found. Please log in again.");
    window.location.href = "login.html";
    return;
  }
 
  fetch(`/api/technician/email/${encodeURIComponent(email)}`)
    .then(res => res.json())
    .then(data => {
      technicianLocation = data.location;
      technicianName = `${data.firstName} ${data.lastName}`; // Store technician's full name
 
      document.getElementById("technicianProfile").innerHTML = `
        <h2>Technician Profile</h2>
        <p><strong>First Name:</strong> ${data.firstName}</p>
        <p><strong>Last Name:</strong> ${data.lastName}</p>
        <p><strong>Employee ID:</strong> ${data.employeeId}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Mobile:</strong> ${data.phone}</p>
        <p><strong>Role:</strong> ${data.role}</p>
        <p><strong>Location:</strong> ${data.location}</p>
      `;
      loadLocations();
    })
    .catch(err => {
      console.error("Error loading profile:", err);
      document.getElementById("technicianProfile").innerHTML = `<p>Error loading profile.</p>`;
    });
}
 
function loadLocations() {
  fetch('/api/locations')
    .then(res => res.json())
    .then(data => {
      const locationDropdown = document.getElementById("location");
      locationDropdown.innerHTML = '<option value="">Select Location</option>';
      data.forEach(loc => {
        const opt = document.createElement("option");
        opt.value = loc;
        opt.textContent = loc;
        locationDropdown.appendChild(opt);
      });
    })
    .catch(err => console.error("Error loading locations:", err));
}
 
function loadBranches() {
  const location = document.getElementById("location").value;
  if (location !== technicianLocation) {
    alert("You don't have access to update machines in this location.");
    document.getElementById("location").value = "";
    return;
  }
 
  fetch(`/api/branches?location=${location}`)
    .then(res => res.json())
    .then(data => {
      const branchDropdown = document.getElementById("branch");
      branchDropdown.innerHTML = '<option value="">Select Branch</option>';
      data.forEach(branch => {
        const opt = document.createElement("option");
        opt.value = branch;
        opt.textContent = branch;
        branchDropdown.appendChild(opt);
      });
    });
}
 
function loadBuildings() {
  const location = document.getElementById("location").value;
  const branch = document.getElementById("branch").value;
  fetch(`/api/buildings?location=${location}&branch=${branch}`)
    .then(res => res.json())
    .then(data => {
      const buildingDropdown = document.getElementById("building");
      buildingDropdown.innerHTML = '<option value="">Select Building</option>';
      data.forEach(building => {
        const opt = document.createElement("option");
        opt.value = building;
        opt.textContent = building;
        buildingDropdown.appendChild(opt);
      });
    });
}
 
function loadFloors() {
  const location = document.getElementById("location").value;
  const branch = document.getElementById("branch").value;
  const building = document.getElementById("building").value;
  fetch(`/api/floors?location=${location}&branch=${branch}&building=${building}`)
    .then(res => res.json())
    .then(data => {
      const floorDropdown = document.getElementById("floor");
      floorDropdown.innerHTML = '<option value="">Select Floor</option>';
      data.forEach(floor => {
        const opt = document.createElement("option");
        opt.value = floor;
        opt.textContent = floor;
        floorDropdown.appendChild(opt);
      });
    });
}
 
function loadMachines() {
  const location = document.getElementById("location").value;
  const branch = document.getElementById("branch").value;
  const building = document.getElementById("building").value;
  const floor = document.getElementById("floor").value;
  fetch(`/api/machines?location=${location}&branch=${branch}&building=${building}&floor=${floor}`)
    .then(res => res.json())
    .then(data => {
      const machineDropdown = document.getElementById("machine");
      machineDropdown.innerHTML = '<option value="">Select Machine</option>';
      data.forEach(machine => {
        const opt = document.createElement("option");
        opt.value = machine;
        opt.textContent = machine;
        machineDropdown.appendChild(opt);
      });
    });
}
function submitCombinedForm() {
  if (!technicianName) {
    alert("Technician name not loaded yet. Please wait a moment and try again.");
    return;
  }
 
  const machineId = document.getElementById("machine").value;
  const temperature = parseFloat(document.getElementById("temp").value);
  const milkLevel = parseInt(document.getElementById("milkLevel").value);
  const coffeeLevel = parseInt(document.getElementById("coffeeQty").value);
  // const milkPackets = parseInt(document.getElementById("milkPackets").value);
  const sugarLevel = parseInt(document.getElementById("sugarSachets").value);
 
  if (!machineId || isNaN(temperature) || isNaN(milkLevel) || isNaN(coffeeLevel) || isNaN(sugarLevel)) {
    alert("Please fill all the fields correctly before submitting.");
    return;
  }
 
  const payload = {
    machine: {
      machineId: machineId
    },
    temperature,
    milkLevel,
    coffeeLevel,
    sugarLevel,
    updatedBy: technicianName
  };
 
  console.log("Submitting payload:", payload); //  Debug log
 
  fetch("/api/machine-details", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => {
      if (res.ok) {
        alert("Machine details updated successfully!");
        showSection("backgroundImage", "homeButton");
      } else {
        alert("Failed to update machine details.");
      }
    });
}


function logoutTechnician() {
  localStorage.clear();
  sessionStorage.clear();

  Swal.fire({
    icon: 'success',
    title: 'Logged out',
    text: 'You have been successfully logged out!',
    confirmButtonText: 'OK'
  }).then(() => {
    window.location.href = 'HomePage.html';
  });
}
